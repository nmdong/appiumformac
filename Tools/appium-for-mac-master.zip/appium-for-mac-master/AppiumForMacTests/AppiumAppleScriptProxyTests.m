//
//  AppiumAppleScriptProxyTests.m
//  AppiumAppleScriptProxyTests
//
//  Created by Dan Cuellar on 7/27/13.
//  Copyright (c) 2013 Appium. All rights reserved.
//

#import "AppiumAppleScriptProxyTests.h"

@implementation AppiumAppleScriptProxyTests

- (void)setUp
{
    [super setUp];
    
    // Set-up code here.
}

- (void)tearDown
{
    // Tear-down code here.
    
    [super tearDown];
}

- (void)testExample
{
    STFail(@"Unit tests are not implemented yet in AppiumAppleScriptProxyTests");
}

@end
