//
//  AppiumMacHTTP303JSONResponse.h
//  AppiumForMac
//
//  Created by Dan Cuellar on 7/28/13.
//  Copyright (c) 2013 Appium. All rights reserved.
//

#import "AppiumMacHTTPJSONResponse.h"

@interface AppiumMacHTTP303JSONResponse : AppiumMacHTTPJSONResponse

@end
