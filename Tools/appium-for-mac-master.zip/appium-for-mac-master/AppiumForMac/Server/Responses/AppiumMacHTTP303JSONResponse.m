//
//  AppiumMacHTTP303JSONResponse.m
//  AppiumForMac
//
//  Created by Dan Cuellar on 7/28/13.
//  Copyright (c) 2013 Appium. All rights reserved.
//

#import "AppiumMacHTTP303JSONResponse.h"

@implementation AppiumMacHTTP303JSONResponse

-(NSInteger) status
{
    return 303;
}

@end
